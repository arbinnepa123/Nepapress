<?php
/**
 * Basmil:The Milan functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Basmil:The_Milan
 */

if ( ! defined( '_S_VERSION' ) ) {
	// Replace the version number of the theme on each release.
	define( '_S_VERSION', '1.0.0' );
}

/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 */
function irl_theme_setup() {
	/*
		* Make theme available for translation.
		* Translations can be filed in the /languages/ directory.
		* If you're building a theme based on Basmil:The Milan, use a find and replace
		* to change 'irl-theme' to the name of your theme in all the template files.
		*/
	load_theme_textdomain( 'irl-theme', get_template_directory() . '/languages' );

	// Add default posts and comments RSS feed links to head.
	add_theme_support( 'automatic-feed-links' );

	/*
		* Let WordPress manage the document title.
		* By adding theme support, we declare that this theme does not use a
		* hard-coded <title> tag in the document head, and expect WordPress to
		* provide it for us.
		*/
	add_theme_support( 'title-tag' );

	/*
		* Enable support for Post Thumbnails on posts and pages.
		*
		* @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		*/
	add_theme_support( 'post-thumbnails' );

	// This theme uses wp_nav_menu() in one location.
	register_nav_menus(
		array(
			'menu-1' => esc_html__( 'Primary', 'irl-theme' ),
		)
	);

	/*
		* Switch default core markup for search form, comment form, and comments
		* to output valid HTML5.
		*/
	add_theme_support(
		'html5',
		array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
			'style',
			'script',
		)
	);

	// Set up the WordPress core custom background feature.
	add_theme_support(
		'custom-background',
		apply_filters(
			'irl_theme_custom_background_args',
			array(
				'default-color' => 'ffffff',
				'default-image' => '',
			)
		)
	);

	// Add theme support for selective refresh for widgets.
	add_theme_support( 'customize-selective-refresh-widgets' );

	/**
	 * Add support for core custom logo.
	 *
	 * @link https://codex.wordpress.org/Theme_Logo
	 */
	add_theme_support(
		'custom-logo',
		array(
			'height'      => 250,
			'width'       => 250,
			'flex-width'  => true,
			'flex-height' => true,
		)
	);
}
add_action( 'after_setup_theme', 'irl_theme_setup' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function irl_theme_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'irl_theme_content_width', 640 );
}
add_action( 'after_setup_theme', 'irl_theme_content_width', 0 );

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function irl_theme_widgets_init() {
	register_sidebar(
		array(
			'name'          => esc_html__( 'Sidebar', 'irl-theme' ),
			'id'            => 'sidebar-1',
			'description'   => esc_html__( 'Add widgets here.', 'irl-theme' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h2 class="widget-title">',
			'after_title'   => '</h2>',
		)
	);
}
add_action( 'widgets_init', 'irl_theme_widgets_init' );

/**
 * Enqueue scripts and styles.
 */
function irl_theme_scripts() {
	wp_enqueue_style( 'irl-theme-style', get_stylesheet_uri(), array(), _S_VERSION );
	wp_style_add_data( 'irl-theme-style', 'rtl', 'replace' );

	wp_enqueue_script( 'irl-theme-navigation', get_template_directory_uri() . '/js/navigation.js', array(), _S_VERSION, true );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'irl_theme_scripts' );

/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require get_template_directory() . '/inc/template-functions.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Load Jetpack compatibility file.
 */
if ( defined( 'JETPACK__VERSION' ) ) {
	require get_template_directory() . '/inc/jetpack.php';
}


function nepa_irl_meta_box() {
    add_meta_box(
        'nepa_irl_meta_box',
        'Nepa Irl',
        'nepa_irl_meta_box_callback',
        'nepa_irl',
        'normal',
        'default'
    );
}
add_action( 'add_meta_boxes', 'nepa_irl_meta_box' );

function nepa_irl_meta_box_callback( $post ) {
    $irl_sel_rud = get_post_meta( $post->ID, '_irl_sel_rud', true );
	$irl_rud_size = get_post_meta( $post->ID, '_irl_rud_size', true );
    $irl_rud_wght = get_post_meta( $post->ID, '_irl_rud_wght', true );
    $irl_front_img = get_post_meta( $post->ID, '_irl_front_img', true );    
    $irl_back_img = get_post_meta( $post->ID, '_irl_back_img', true );
    ?>
    <div>
        <p><button type="button" id="add_irl">Add Irl</button></p>
        <div id="irl_fields" style="display: flex; flex-wrap: wrap; gap:20px; margin-bottom:20px;">
            <?php if ( $irl_sel_rud ) : ?>
                <?php foreach ( $irl_sel_rud as $key=>$value ) : ?>
                    <div style="padding:10px; display:flex; max-width:22%; flex-direction:column; gap:10px; position: relative; background:#c4c4c4;">
						<label>Select Rudraksha</label>
						<select name="_irl_sel_rud[]" class="irl_select">
							<option value="1mukhi" <?php selected( $value, '1mukhi' ); ?>>1mukhi</option>
                            <option value="2mukhi" <?php selected( $value, '2mukhi' ); ?>>2mukhi</option>
                            <option value="3mukhi" <?php selected( $value, '3mukhi' ); ?>>3mukhi</option>
                            <option value="4mukhi" <?php selected( $value, '4mukhi' ); ?>>4mukhi</option>
                            <option value="5mukhi" <?php selected( $value, '5mukhi' ); ?>>5mukhi</option>
                        </select>
						<label>Rudraksha Length</label>
						<input type="text" name="_irl_rud_size[]" value="<?php echo $irl_rud_size[$key]; ?>">
						<label>Rudraksha Weight</label>
						<input type="text" name="_irl_rud_wght[]" value="<?php echo $irl_rud_wght[$key]; ?>">
						<label>Front Image</label>
                        <img style="border-radius:50%; "  src="<?php echo esc_url( $irl_front_img[$key] ); ?>" alt="No image selected"/>
                        <input type="text" class="irl_front_img-url" name="_irl_front_img[]" value="<?php echo esc_attr( $irl_front_img[$key] ); ?>" hidden/>
                        <input type="button" class="upload-irl_img button" value="Upload" />
						
						<label>Back Image</label>
                        <img style="border-radius:50%; "  src="<?php echo esc_url( $irl_back_img[$key] ); ?>" alt="No image selected"/>
                        <input type="text" class="irl_back_img-url" name="_irl_back_img[]" value="<?php echo esc_attr( $irl_back_img[$key] ); ?>" hidden/>
                        <input type="button" class="upload-irl_img button" value="Upload" />
						
						<button type="button" class="delete_irl">Delete</button>

					</div>
                    
                <?php endforeach; ?>
            <?php else : ?>
                
				<div style="padding:10px; display:flex; max-width:22%; flex-direction:column; gap:10px; position: relative; background:#c4c4c4;">
						<label>Select Rudraksha</label>
						<select name="_irl_sel_rud[]" class="irl_select">
							<option value="1mukhi">1mukhi</option>
                            <option value="2mukhi">2mukhi</option>
                            <option value="3mukhi">3mukhi</option>
                            <option value="4mukhi">4mukhi</option>
                            <option value="5mukhi">5mukhi</option>
                        </select>
						<label>Rudraksha Length</label>
						<input type="text" name="_irl_rud_size[]">
						<label>Rudraksha Weight</label>
						<input type="text" name="_irl_rud_wght[]">
						<label>Front Image</label>
                        <img style="border-radius:50%; "  src="" alt="No image selected"/>
                        <input type="text" class="irl_front_img-url" name="_irl_front_img[]"  hidden/>
                        <input type="button" class="upload-irl_img button" value="Upload" />
						
						<label>Back Image</label>
                        <img style="border-radius:50%; "  src="" alt="No image selected"/>
                        <input type="text" class="irl_back_img-url" name="_irl_back_img[]"  hidden/>
                        <input type="button" class="upload-irl_img button" value="Upload" />
						
						<button type="button" class="delete_irl">Delete</button>

					</div>
            <?php endif; ?>
			<script>
        jQuery(document).ready(function($) {
            var container = $('#irl_fields');
            $(container).on('click', '.upload-irl_img', function() {
                var imageField = $(this).prev();
                var frame = wp.media({
                    title: 'Select Image',
                    multiple: false,
                    library: { type: 'image' },
                    button: { text: 'Select' }
                });
                frame.on('select', function() {
                    var attachment = frame.state().get('selection').first().toJSON();
                    $(imageField).val(attachment.url);
                    $(imageField).prev().attr('src',attachment.url);
                });
                frame.open();
            });
        });
    </script>
        </div>
    </div>

	<script>
		jQuery(document).ready(function($) {
			// Add Irl field
			$('#add_irl').click(function(e) {
				e.preventDefault();
				$('#irl_fields').append('<div style="padding:10px; display:flex; max-width:22%; flex-direction:column; gap:10px; position: relative; background:#c4c4c4;"><label>Select Rudraksha</label><select name="_irl_sel_rud[]" class="irl_select"><option value="1mukhi">1mukhi</option><option value="2mukhi">2mukhi</option><option value="3mukhi">3mukhi</option><option value="4mukhi">4mukhi</option><option value="5mukhi">5mukhi</option></select><label>Rudraksha Length</label><input type="text" name="_irl_rud_size[]"><label>Rudraksha Weight</label><input type="text" name="_irl_rud_wght[]"><label>Front Image</label><img style="border-radius:50%; "  src="" alt="No image selected"/><input type="text" class="irl_front_img-url" name="_irl_front_img[]"  hidden/><input type="button" class="upload-irl_img button" value="Upload" /><label>Back Image</label><img style="border-radius:50%; "  src="" alt="No image selected"/><input type="text" class="irl_back_img-url" name="_irl_back_img[]"  hidden/><input type="button" class="upload-irl_img button" value="Upload" /><button type="button" class="delete_irl">Delete</button></div>');
			});

			// Delete Irl field
			$('#irl_fields').on('click', '.delete_irl', function() {
				$(this).parent().remove();
			});
		});
	</script>
<?php 
}

function save_nepa_irl_sel_rud( $post_id ) {
    if ( ! isset( $_POST['_irl_sel_rud'] ) ) {
		delete_post_meta( $post_id, '_irl_sel_rud' );
        return;
    }

    $irl_sel_rud = array_map( 'sanitize_text_field', $_POST['_irl_sel_rud'] );
    update_post_meta( $post_id, '_irl_sel_rud', $irl_sel_rud );

	$irl_rud_size = array_map( 'sanitize_text_field', $_POST['_irl_rud_size'] );
    update_post_meta( $post_id, '_irl_rud_size', $irl_rud_size );

	$irl_rud_wght = array_map( 'sanitize_text_field', $_POST['_irl_rud_wght'] );
    update_post_meta( $post_id, '_irl_rud_wght', $irl_rud_wght );

	$irl_front_img = $_POST['_irl_front_img'] ;
    update_post_meta( $post_id, '_irl_front_img', $irl_front_img );

	$irl_back_img = $_POST['_irl_back_img'];
    update_post_meta( $post_id, '_irl_back_img', $irl_back_img );

}

add_action( 'save_post_nepa_irl', 'save_nepa_irl_sel_rud' );


function display_nepa_irl_sel_rud_shortcode( $atts ) {
    $post_id = get_the_ID();
    $irl_sel_rud = get_post_meta( $post_id, '_irl_sel_rud', true );
    if ( ! empty( $irl_sel_rud ) ) {

		// Convert the PHP array to a JSON string
		$irl_sel_rud_json = json_encode( $irl_sel_rud );

		// Output the JSON string as a JavaScript array
		echo '<script>var values = ' . $irl_sel_rud_json . ';</script>';
       
    }

}
// add_shortcode( 'nepa_irl_sel_rud', 'display_nepa_irl_sel_rud_shortcode' );

